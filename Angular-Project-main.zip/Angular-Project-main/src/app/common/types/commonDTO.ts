export interface PropertiesDTO {
    firstName?: string;
    lastName?: string;
   
}

export interface CommonDTO {
    userId?: number;
    id?: number;
    title?: string;
    completed?: boolean;
    
}